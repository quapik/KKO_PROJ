//Projekt do KKO, 5.5.2023, VUT FIT, Vojtěch Šíma, xsimav01
//decode.h hlavičkový soubor pro decode_adapt.cpp 
#include "huff_codec.h"

void Decode_adapt(string inputFile, string outputFile, bool model);