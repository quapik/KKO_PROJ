//Projekt do KKO, 5.5.2023, VUT FIT, Vojtěch Šíma, xsimav01
//huff_codec.h hlavičkový soubor pro huff_codec.cpp 
#include <iostream>
#include <fstream>
#include <getopt.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <cstdint> 
#include <algorithm>
#include <limits.h>
#include <bitset>
using namespace std;
#define GRAYSCALE_SIZE 256