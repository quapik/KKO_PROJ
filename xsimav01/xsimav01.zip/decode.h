//Projekt do KKO, 5.5.2023, VUT FIT, Vojtěch Šíma, xsimav01
//decode.h hlavičkový soubor pro decode.cpp 
#include "huff_codec.h"
void Decode(string inputFile, string outputFile, bool model, bool adapt);